$(document).ready(function() {
	$('.datetime').datetimepicker({
	    format: 'yyyy-mm-dd hh:ii',
	    autoclose: 1,
	});	

});
